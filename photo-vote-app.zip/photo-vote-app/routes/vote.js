const express = require('express');
const db = require('../config/db');
const { requireLogin } = require('../middleware/auth');
const { getVoteStatus, isResultsRevealed, getSetting } = require('../config/helpers');

const router = express.Router();

// ---------- หน้าหลักโหวต ----------
router.get('/vote', requireLogin, (req, res) => {
  const photos = db.prepare('SELECT * FROM photos ORDER BY created_at ASC').all();
  const myVotes = db
    .prepare('SELECT photo_id FROM votes WHERE user_id = ?')
    .all(req.session.user.id)
    .map((v) => v.photo_id);

  res.render('vote', {
    user: req.session.user,
    photos,
    myVotes,
    status: getVoteStatus(),
    voteStart: getSetting('vote_start'),
    voteEnd: getSetting('vote_end'),
    message: req.query.msg || null,
  });
});

// ---------- โหวตรูปภาพ ----------
router.post('/vote/:photoId', requireLogin, (req, res) => {
  const status = getVoteStatus();
  const photoId = parseInt(req.params.photoId, 10);

  if (status !== 'open') {
    return res.redirect('/vote?msg=' + encodeURIComponent('ขณะนี้ไม่อยู่ในช่วงเวลาที่เปิดให้โหวต'));
  }

  const photo = db.prepare('SELECT * FROM photos WHERE id = ?').get(photoId);
  if (!photo) {
    return res.redirect('/vote?msg=' + encodeURIComponent('ไม่พบรูปภาพนี้'));
  }

  const already = db
    .prepare('SELECT id FROM votes WHERE user_id = ? AND photo_id = ?')
    .get(req.session.user.id, photoId);

  if (already) {
    return res.redirect('/vote?msg=' + encodeURIComponent('คุณโหวตรูปนี้ไปแล้ว'));
  }

  db.prepare('INSERT INTO votes (user_id, photo_id) VALUES (?, ?)').run(req.session.user.id, photoId);

  res.redirect('/vote?msg=' + encodeURIComponent('โหวตสำเร็จ! ขอบคุณที่ร่วมโหวต'));
});

// ---------- หน้าผลโหวต (สาธารณะสำหรับผู้ล็อกอิน) ----------
router.get('/results', requireLogin, (req, res) => {
  const revealed = isResultsRevealed();

  let photos = [];
  if (revealed) {
    photos = db
      .prepare(
        `SELECT p.*, COUNT(v.id) as vote_count
         FROM photos p
         LEFT JOIN votes v ON v.photo_id = p.id
         GROUP BY p.id
         ORDER BY vote_count DESC, p.created_at ASC`
      )
      .all();
  }

  res.render('results', { revealed, photos });
});

module.exports = router;
