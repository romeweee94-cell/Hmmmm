const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { redirectIfLoggedIn } = require('../middleware/auth');

const router = express.Router();

// ---------- หน้าล็อกอิน (ผู้ใช้ทั่วไป) ----------
router.get('/login', redirectIfLoggedIn, (req, res) => {
  res.render('login', { error: null });
});

router.post('/login', redirectIfLoggedIn, (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.render('login', { error: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ? AND role = ?').get(username.trim(), 'user');

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.render('login', { error: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }

  req.session.user = { id: user.id, username: user.username, role: user.role };
  res.redirect('/vote');
});

// ---------- หน้าสมัครสมาชิก (ผู้ใช้ทั่วไป) ----------
router.get('/register', redirectIfLoggedIn, (req, res) => {
  res.render('register', { error: null });
});

router.post('/register', redirectIfLoggedIn, (req, res) => {
  const { username, password, confirm_password } = req.body;

  if (!username || !password || !confirm_password) {
    return res.render('register', { error: 'กรุณากรอกข้อมูลให้ครบทุกช่อง' });
  }
  if (username.trim().length < 3) {
    return res.render('register', { error: 'ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร' });
  }
  if (password.length < 6) {
    return res.render('register', { error: 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร' });
  }
  if (password !== confirm_password) {
    return res.render('register', { error: 'รหัสผ่านทั้งสองช่องไม่ตรงกัน' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username.trim());
  if (existing) {
    return res.render('register', { error: 'มีชื่อผู้ใช้นี้อยู่แล้วในระบบ' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)')
    .run(username.trim(), hash, 'user');

  req.session.user = { id: info.lastInsertRowid, username: username.trim(), role: 'user' };
  res.redirect('/vote');
});

// ---------- ล็อกเอาท์ ----------
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

module.exports = router;
