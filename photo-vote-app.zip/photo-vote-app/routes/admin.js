const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { requireAdmin } = require('../middleware/auth');
const { getAllSettings, setSetting, getVoteStatus } = require('../config/helpers');

const router = express.Router();
const ADMIN_SECRET_CODE = process.env.ADMIN_SECRET_CODE || 'PhaiZa080800272870';

// ---------- ตั้งค่าอัปโหลดรูปภาพ ----------
const uploadDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext;
    cb(null, safeName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 }, // 8MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) return cb(null, true);
    cb(new Error('รองรับเฉพาะไฟล์รูปภาพ (jpg, jpeg, png, webp, gif) เท่านั้น'));
  },
});

// ================= ADMIN AUTH =================

// ---------- สมัครแอดมิน (ต้องใส่รหัสลับให้ตรงกันทั้งช่องบนและล่าง) ----------
router.get('/admin/register', (req, res) => {
  res.render('admin-register', { error: null });
});

router.post('/admin/register', (req, res) => {
  const { username, password, code_top, code_bottom } = req.body;

  if (!username || !password || !code_top || !code_bottom) {
    return res.render('admin-register', { error: 'กรุณากรอกข้อมูลให้ครบทุกช่อง' });
  }

  if (code_top !== ADMIN_SECRET_CODE || code_bottom !== ADMIN_SECRET_CODE) {
    return res.render('admin-register', { error: 'รหัสลับแอดมินไม่ถูกต้อง (ต้องกรอกให้ตรงกันทั้งช่องบนและล่าง)' });
  }

  if (code_top !== code_bottom) {
    return res.render('admin-register', { error: 'รหัสช่องบนและช่องล่างไม่ตรงกัน' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username.trim());
  if (existing) {
    return res.render('admin-register', { error: 'มีชื่อผู้ใช้นี้อยู่แล้วในระบบ' });
  }

  const hash = bcrypt.hashSync(password, 10);
  db.prepare('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)').run(
    username.trim(),
    hash,
    'admin'
  );

  res.redirect('/admin/login');
});

// ---------- ล็อกอินแอดมิน ----------
router.get('/admin/login', (req, res) => {
  res.render('admin-login', { error: null });
});

router.post('/admin/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.render('admin-login', { error: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' });
  }

  const admin = db.prepare('SELECT * FROM users WHERE username = ? AND role = ?').get(username.trim(), 'admin');

  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.render('admin-login', { error: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }

  req.session.user = { id: admin.id, username: admin.username, role: 'admin' };
  res.redirect('/admin');
});

// ================= ADMIN DASHBOARD =================

router.get('/admin', requireAdmin, (req, res) => {
  const photos = db
    .prepare(
      `SELECT p.*, COUNT(v.id) as vote_count
       FROM photos p
       LEFT JOIN votes v ON v.photo_id = p.id
       GROUP BY p.id
       ORDER BY p.created_at ASC`
    )
    .all();

  const voters = db
    .prepare(
      `SELECT u.username, p.title as photo_title, v.created_at
       FROM votes v
       JOIN users u ON u.id = v.user_id
       JOIN photos p ON p.id = v.photo_id
       ORDER BY v.created_at DESC`
    )
    .all();

  const totalUsers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'user'").get().c;
  const totalVotes = db.prepare('SELECT COUNT(*) as c FROM votes').get().c;

  res.render('admin-dashboard', {
    admin: req.session.user,
    photos,
    voters,
    settings: getAllSettings(),
    status: getVoteStatus(),
    totalUsers,
    totalVotes,
    message: req.query.msg || null,
    error: req.query.err || null,
  });
});

// ---------- เพิ่มรูปภาพ ----------
router.post('/admin/photos', requireAdmin, (req, res) => {
  upload.single('image')(req, res, (err) => {
    if (err) {
      return res.redirect('/admin?err=' + encodeURIComponent(err.message));
    }
    const { title } = req.body;
    if (!title || !req.file) {
      return res.redirect('/admin?err=' + encodeURIComponent('กรุณาใส่ชื่อรูปและเลือกไฟล์รูปภาพ'));
    }
    db.prepare('INSERT INTO photos (title, filename) VALUES (?, ?)').run(title.trim(), req.file.filename);
    res.redirect('/admin?msg=' + encodeURIComponent('เพิ่มรูปภาพสำเร็จ'));
  });
});

// ---------- ลบรูปภาพ ----------
router.post('/admin/photos/:id/delete', requireAdmin, (req, res) => {
  const photo = db.prepare('SELECT * FROM photos WHERE id = ?').get(req.params.id);
  if (photo) {
    const filePath = path.join(uploadDir, photo.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    db.prepare('DELETE FROM photos WHERE id = ?').run(req.params.id);
  }
  res.redirect('/admin?msg=' + encodeURIComponent('ลบรูปภาพแล้ว'));
});

// ---------- ตั้งเวลาเปิด/ปิดโหวต ----------
router.post('/admin/schedule', requireAdmin, (req, res) => {
  const { vote_start, vote_end } = req.body;
  setSetting('vote_start', vote_start || '');
  setSetting('vote_end', vote_end || '');
  res.redirect('/admin?msg=' + encodeURIComponent('อัปเดตเวลาการโหวตแล้ว'));
});

// ---------- เปิด/ปิดการเฉลยผลโหวต ----------
router.post('/admin/reveal', requireAdmin, (req, res) => {
  const { action } = req.body; // 'reveal' หรือ 'hide'
  setSetting('results_revealed', action === 'reveal' ? '1' : '0');
  res.redirect('/admin?msg=' + encodeURIComponent(action === 'reveal' ? 'เฉลยผลโหวตแล้ว' : 'ซ่อนผลโหวตแล้ว'));
});

// ---------- ล็อกเอาท์แอดมิน ----------
router.post('/admin/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
});

module.exports = router;
