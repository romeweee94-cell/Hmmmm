const db = require('./db');

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : '';
}

function setSetting(key, value) {
  db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  ).run(key, value);
}

function getAllSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const obj = {};
  rows.forEach((r) => (obj[r.key] = r.value));
  return obj;
}

// คืนสถานะการโหวตปัจจุบัน: 'not_started' | 'open' | 'closed' | 'no_schedule'
function getVoteStatus() {
  const start = getSetting('vote_start');
  const end = getSetting('vote_end');

  if (!start || !end) return 'no_schedule';

  const now = new Date();
  const startDate = new Date(start);
  const endDate = new Date(end);

  if (now < startDate) return 'not_started';
  if (now > endDate) return 'closed';
  return 'open';
}

function isResultsRevealed() {
  return getSetting('results_revealed') === '1';
}

module.exports = {
  getSetting,
  setSetting,
  getAllSettings,
  getVoteStatus,
  isResultsRevealed,
};
